import json

from flask import Flask, request, make_response, render_template, session, redirect
from flask_sock import Sock, Server

from exceptions import MessageException

app = Flask("SkysmartMakerService")
sock = Sock(app)

app.secret_key = 'AUfy1@#uig!!jf?5r&^@!'


@app.get('/setauth')
def setauth():
    return render_template("setauth.html")


@app.post('/setauth')
def setauthpost():
    resp = redirect('/')
    for key, value in request.form.items():
        resp.set_cookie(key, value, httponly=True)
    session['authorized'] = True
    return resp


@app.get('/')
def index():
    if not session.get('authorized'):
        return redirect('/setauth')
    return render_template('index.html')


@sock.route('/maker')
def makerstate(ws: Server):
    from maker import do_task, create_watcher
    from typing import TypedDict

    class Config(TypedDict):
        url: str
        score: int

    config_raw: str = ws.receive()
    config: Config = json.loads(config_raw)

    task = config['url'].split('/')[-1]
    score: int = config['score']

    watcher = create_watcher({
        'making': 'Выполняется {0} из {1}...',
        'auth': "Аутентификация...",
        'start': "Запуск задачи...",
        'finish': "Завершено!",
        'init': "Инициализация",
        'setup': "Подготовка к выполнению"
    }, ws.send)

    try:
        do_task(task, score, request.cookies['email'], request.cookies['password'], watcher)
    except MessageException as e:
        ws.send("Ошибка: " + e.message)
    except Exception as e:
        ws.send("Произошла непредвиденная ошибка")

    ws.close()


if __name__ == '__main__':
    app.run()
